import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader

class DummyAlphaDataset(Dataset):
    def __init__(self, num_samples=100):
        self.num_samples = num_samples
        
    def __len__(self):
        return self.num_samples
        
    def __getitem__(self, idx):
        # 1. Temporal View (T=30 days, S=5 stocks)
        X_i = torch.randn(30, 5)
        # Morphology View (Augmentation) - simulate moving average smoothing
        X_aug = X_i + torch.randn(30, 5) * 0.1 
        
        # 2. AST View (Max len = 20)
        tokens = torch.randint(0, 500, (20,))
        depths = torch.randint(0, 10, (20,))
        
        # Random valid length between 5 and 20
        valid_len = torch.randint(5, 21, (1,)).item()
        ast_mask = torch.zeros(20)
        ast_mask[:valid_len] = 1.0
        
        # 3. Targets and weights
        labels = torch.randint(0, 2, (5,)).float()
        alpha_weights = torch.ones(5)
        
        # Dummy TED matrix (will be constructed across batch in collate, 
        # but for toy we just return dummy values)
        return X_i, X_aug, tokens, depths, ast_mask, labels, alpha_weights

def collate_fn(batch):
    X_i = torch.stack([b[0] for b in batch])
    X_aug = torch.stack([b[1] for b in batch])
    tokens = torch.stack([b[2] for b in batch])
    depths = torch.stack([b[3] for b in batch])
    ast_mask = torch.stack([b[4] for b in batch])
    labels = torch.stack([b[5] for b in batch])
    alpha_weights = torch.stack([b[6] for b in batch])
    
    # Construct a dummy TED distance matrix for the batch
    batch_size = len(batch)
    ted_matrix = torch.rand(batch_size, batch_size)
    ted_matrix = (ted_matrix + ted_matrix.T) / 2 # make symmetric
    ted_matrix.fill_diagonal_(0.0)
    
    return X_i, X_aug, tokens, depths, ast_mask, labels, alpha_weights, ted_matrix

def get_toy_dataloader(batch_size=16):
    dataset = DummyAlphaDataset(num_samples=64)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
