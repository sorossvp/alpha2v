import torch
import torch.nn as nn
import numpy as np
import argparse
import time

from models.ast_encoder import ASTEncoder
from models.temporal_encoder import TemporalBackbone
from models.fusion_module import Alpha2VFusion
from utils.data_loader import get_toy_dataloader

def evaluate(args):
    print("Initializing Alpha2V models for evaluation...")
    ast_enc = ASTEncoder(vocab_size=500, max_depth=10, embed_dim=64)
    ts_enc = TemporalBackbone(input_dim=5, hidden_dim=256, n_layers=2, out_dim=128)
    fusion = Alpha2VFusion(ts_dim=128, ast_dim=64)
    dummy_classifier = nn.Linear(128, 5)
    
    ast_enc.eval()
    ts_enc.eval()
    fusion.eval()
    dummy_classifier.eval()
    
    print("Loading test dataset...")
    dataloader = get_toy_dataloader(batch_size=args.batch_size)
    
    all_embeddings = []
    all_labels = []
    all_preds = []
    
    print("Starting inference...")
    start_time = time.time()
    
    with torch.no_grad():
        for batch in dataloader:
            X_i, _, tokens, depths, ast_mask, labels, _, _ = batch
            
            h_ts = ts_enc(X_i)
            h_ast = ast_enc(tokens, depths, ast_mask)
            z_i = fusion(h_ts, h_ast, ast_mask)
            
            preds = torch.sigmoid(dummy_classifier(z_i))
            
            all_embeddings.append(z_i.cpu().numpy())
            all_labels.append(labels.cpu().numpy())
            all_preds.append((preds > 0.5).float().cpu().numpy())
            
    end_time = time.time()
    
    embeddings = np.concatenate(all_embeddings, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    preds = np.concatenate(all_preds, axis=0)
    
    print(f"Inference completed in {end_time - start_time:.4f} seconds.")
    print(f"Extracted embeddings shape: {embeddings.shape}")
    print(f"Evaluated on {len(embeddings)} dummy samples.")
    print("\n--- Simulated Evaluation Results ---")
    print("Classification Metrics (Toy Data):")
    # Just compute dummy accuracy
    acc = (preds == labels).mean()
    print(f"  - Micro Accuracy: {acc * 100:.2f}%")
    print("Retrieval Metrics (Toy Data):")
    print("  - Scalability: O(N) using FAISS index (Simulated)")
    print("  - Retrieval time per query: < 1 ms (Simulated)")
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Alpha2V Evaluation Sanity Check")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size")
    parser.add_argument("--dataset_path", type=str, default="./data/toy_dataset/", help="Path to dataset")
    args = parser.parse_args()
    
    evaluate(args)
