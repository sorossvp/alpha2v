# Alpha2V: Unified Vector Representation Learning for Formulaic Alphas (ICASSP 2027)

This is the anonymous repository for the paper: **Alpha2V: Unified Vector Representation Learning for Formulaic Alphas in Automated Alpha Systems**.

## 1. Directory Structure

```text
.
├── models/
│   ├── ast_encoder.py        # AST Token-Depth embedding module
│   ├── temporal_encoder.py   # Transformer-based timeseries backbone
│   ├── fusion_module.py      # Triple cross-attention late fusion
│   └── alpha2v_loss.py       # Attribute-Balanced Focal Loss + InfoNCE + TED Align
├── data/
│   └── toy_dataset/          # Anonymized toy dataset for sanity check
├── utils/
│   └── data_loader.py        # Dataset & DataLoader for multimodal inputs
├── train.py                  # Main training loop
├── eval.py                   # Evaluation script for retrieval & classification
├── requirements.txt          # Dependencies
└── README.md
```

## 2. About the Data

**Full Dataset**: The original experiments were conducted on a proprietary dataset comprising 25 years of China A-share market data (spanning thousands of stocks). Due to strict commercial copyright agreements and the massive size of the data (hundreds of GBs), we are **unable to distribute the full dataset directly**.

**Toy Dataset**: To ensure the reproducibility of our code architecture, we provide a heavily down-sampled, anonymized, and noise-injected `toy_dataset` (located in `data/toy_dataset/`). This dataset contains dummy formula AST representations and randomly generated scale-preserving timeseries tensors for a synthetic universe of 5 stocks over 30 days. It is intended **strictly for sanity checking the codebase** (e.g., verifying forward/backward passes and loss computations) and will not yield meaningful financial returns.

## 3. Quick Start (Sanity Check)

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run training on the toy dataset**:
   ```bash
   python train.py --epochs 2 --batch_size 16 --dataset_path ./data/toy_dataset/
   ```
   This will execute the multi-objective optimization (Attribute-Balanced Focal Loss, Structure-Alignment Loss, and InfoNCE) on the synthetic data.

## 4. Dependencies
- Python >= 3.8
- PyTorch >= 2.0.0
- NumPy >= 1.24
- Pandas >= 2.0
