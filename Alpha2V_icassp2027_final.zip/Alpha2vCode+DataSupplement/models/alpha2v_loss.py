import torch
import torch.nn as nn
import torch.nn.functional as F

class Alpha2VLoss(nn.Module):
    def __init__(self, gamma=2.0, tau_ted=1.0, tau_nce=0.07):
        super().__init__()
        self.gamma = gamma
        self.tau_ted = tau_ted
        self.tau_nce = tau_nce

    def forward(self, z, z_aug, preds, labels, alpha_weights, ted_matrix):
        # 1. Attribute-Balanced Focal Loss
        bce = F.binary_cross_entropy_with_logits(preds, labels, reduction='none')
        p_t = torch.exp(-bce)
        focal_loss = (alpha_weights * ((1 - p_t) ** self.gamma) * bce).mean()

        # 2. Structure-Alignment Loss
        z_norm = F.normalize(z, p=2, dim=1)
        sim_matrix = torch.matmul(z_norm, z_norm.T)
        S_ted = torch.exp(-ted_matrix / self.tau_ted)
        align_loss = F.mse_loss(sim_matrix, S_ted)

        # 3. InfoNCE Loss
        z_aug_norm = F.normalize(z_aug, p=2, dim=1)
        pos_sim = torch.sum(z_norm * z_aug_norm, dim=-1) / self.tau_nce
        neg_sim = torch.matmul(z_norm, z_norm.T) / self.tau_nce
        
        mask = torch.eye(z.size(0), device=z.device).bool()
        neg_sim.masked_fill_(mask, -1e9)
        
        logits = torch.cat([pos_sim.unsqueeze(1), neg_sim], dim=1)
        labels_nce = torch.zeros(z.size(0), dtype=torch.long, device=z.device)
        nce_loss = F.cross_entropy(logits, labels_nce)

        return focal_loss, align_loss, nce_loss
