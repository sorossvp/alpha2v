import torch
import torch.nn as nn

class Alpha2VFusion(nn.Module):
    def __init__(self, ts_dim=128, ast_dim=64):
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(embed_dim=ts_dim, num_heads=4, batch_first=True)
        self.k_proj = nn.Linear(ast_dim, ts_dim)
        self.v_proj = nn.Linear(ast_dim, ts_dim)

    def forward(self, h_ts, h_ast, ast_mask):
        k = self.k_proj(h_ast)
        v = self.v_proj(h_ast)
        key_padding_mask = ~ast_mask.bool() 
        fused, _ = self.cross_attn(query=h_ts, key=k, value=v, key_padding_mask=key_padding_mask)
        z = fused.mean(dim=1) 
        return z
