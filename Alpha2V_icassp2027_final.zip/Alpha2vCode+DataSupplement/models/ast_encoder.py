import torch
import torch.nn as nn
import torch.nn.functional as F

class ASTEncoder(nn.Module):
    def __init__(self, vocab_size=500, max_depth=10, embed_dim=64):
        super().__init__()
        self.token_emb = nn.Embedding(vocab_size, embed_dim)
        self.depth_emb = nn.Embedding(max_depth, embed_dim)
        self.proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, tokens, depths, mask):
        t_emb = self.token_emb(tokens)
        d_emb = self.depth_emb(depths)
        h_ast = F.relu(self.proj(t_emb + d_emb))
        return h_ast
