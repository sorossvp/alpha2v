import torch
import torch.nn as nn

class TemporalBackbone(nn.Module):
    def __init__(self, input_dim, hidden_dim=256, n_layers=2, out_dim=128):
        super().__init__()
        # Fix nhead for toy data
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=input_dim, nhead=1, dim_feedforward=hidden_dim, 
            dropout=0.1, batch_first=True, activation='gelu'
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers, enable_nested_tensor=False)
        self.proj = nn.Linear(input_dim, out_dim)

    def forward(self, x):
        h_ts = self.transformer(x)
        h_ts = self.proj(h_ts)
        return h_ts
