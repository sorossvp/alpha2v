import torch
import torch.nn as nn
import numpy as np
import random
import argparse
import os

from models.ast_encoder import ASTEncoder
from models.temporal_encoder import TemporalBackbone
from models.fusion_module import Alpha2VFusion
from models.alpha2v_loss import Alpha2VLoss
from utils.data_loader import get_toy_dataloader

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.backends.cudnn.deterministic = True

def train(args):
    set_seed(args.seed)
    print(f"Random seed set to {args.seed}")
    print("Initializing Alpha2V models...")
    # Initialize components
    ast_enc = ASTEncoder(vocab_size=500, max_depth=10, embed_dim=64)
    ts_enc = TemporalBackbone(input_dim=5, hidden_dim=256, n_layers=2, out_dim=128)
    fusion = Alpha2VFusion(ts_dim=128, ast_dim=64)
    criterion = Alpha2VLoss(gamma=2.0, tau_ted=1.0, tau_nce=0.07)
    
    optimizer = torch.optim.AdamW(
        list(ast_enc.parameters()) + list(ts_enc.parameters()) + list(fusion.parameters()),
        lr=1e-4, weight_decay=1e-4
    )
    
    print("Loading toy dataset...")
    dataloader = get_toy_dataloader(batch_size=args.batch_size)
    
    print("Starting training loop...")
    for epoch in range(args.epochs):
        for batch_idx, batch in enumerate(dataloader):
            X_i, X_aug, tokens, depths, ast_mask, labels, alpha_weights, ted_matrix = batch
            
            optimizer.zero_grad()
            
            # Forward pass
            h_ts = ts_enc(X_i)
            h_ast = ast_enc(tokens, depths, ast_mask)
            z_i = fusion(h_ts, h_ast, ast_mask)
            
            # Augmentation view for contrastive loss
            h_ts_aug = ts_enc(X_aug)
            z_aug = fusion(h_ts_aug, h_ast, ast_mask)
            
            # Dummy prediction head for attribute classification
            dummy_classifier = nn.Linear(128, 5)
            preds = dummy_classifier(z_i)
            
            # Compute Multi-objective loss
            l_focal, l_align, l_nce = criterion(z_i, z_aug, preds, labels, alpha_weights, ted_matrix)
            loss = l_focal + 1.0 * l_align + 0.5 * l_nce
            
            # Backward pass
            loss.backward()
            torch.nn.utils.clip_grad_norm_(ast_enc.parameters(), max_norm=1.0)
            optimizer.step()
            
            if batch_idx % 5 == 0:
                print(f"Epoch {epoch+1} | Batch {batch_idx} | Loss: {loss.item():.4f} (Focal: {l_focal.item():.4f}, Align: {l_align.item():.4f}, NCE: {l_nce.item():.4f})")
                
    print("Training sanity check completed successfully!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Alpha2V Training Sanity Check")
    parser.add_argument("--epochs", type=int, default=2, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size")
    parser.add_argument("--dataset_path", type=str, default="./data/toy_dataset/", help="Path to dataset")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    args = parser.parse_args()
    
    train(args)
